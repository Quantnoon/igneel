
class DataCollection:
    _collections = {}
    def __init__(self, price_data, symbols, timeframes, date_range="1M", indicators=[], set_regime=None):
        price_data.set_price(symbols, date_range, timeframes)
        price_data.set_indicator(indicators)
        for symbol in symbols:
            df = price_data.get_merged_price(symbol)
            if set_regime is not None:
                df = set_regime(df)
            self._collections[symbol] = {
                "data": df,
                "symbol_info": price_data.get_symbol_info(symbol)
            }
    
    def get_collections(self, symbol=None):
        if symbol is not None:
            return self._collections[symbol]
        return self._collections


