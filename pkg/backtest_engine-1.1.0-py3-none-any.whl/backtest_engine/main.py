from .backtest_config import BuildStrategy
from .data_collection import DataCollection

class Engine:
    _symbols = []
    _collection = None
    _config = {}
    _backtest = None
    def __init__(self, price_data, symbols=[], timeframes=[], indicators=[], date_range="1M", set_regime=None):
        self._symbols = symbols
        self._collection = DataCollection(price_data, symbols, timeframes, date_range, indicators, set_regime)
    
    def set_config(self, config, strategy_list):
        self._backtest = BuildStrategy(self._symbols, strategy_list, self._collection)
        self._config = config
    
    def run_backtest(self):
        result = self._backtest.run(self._config)
        return result
