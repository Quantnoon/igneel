def m15_breakout(df, i):
    required_cols = [
        "supply_high_H1",
        "supply_low_H1",
        "demand_high_H1",
        "demand_low_H1",
        "ema_trend_M15",
        "slope_trend_M15",
        "close_M15",
    ]
    for col in required_cols:
        if col not in df.columns:
            return None, None, None

    supply_high = df["supply_high_H1"].values
    supply_low = df["supply_low_H1"].values
    demand_high = df["demand_high_H1"].values
    demand_low = df["demand_low_H1"].values
    ema_trend = df["ema_trend_M15"].values
    slope_trend = df["slope_trend_M15"].values
    entry = df["close_M15"].values

    if (supply_high[i] > entry[i] > supply_low[i]) and (
        ema_trend[i] < entry[i] or slope_trend[i] == "up"
    ):
        sl = supply_high[i]
        tp = supply_low[i]
        return "buy", sl, tp

    if (demand_high[i] > entry[i] > demand_low[i]) and (
        ema_trend[i] > entry[i] or slope_trend[i] == "down"
    ):
        sl = demand_low[i]
        tp = demand_high[i]
        return "sell", sl, tp

    return None, None, None


def exit_signal(df, index, pos):
    slope_trend = df["slope_trend_M15"].values

    if pos == "buy" and slope_trend[index] == "down":
        return True
    elif pos == "sell" and slope_trend[index] == "up":
        return True
    else:
        return False

strategy_list = [
    ("m15_breakout", m15_breakout, exit_signal)
]