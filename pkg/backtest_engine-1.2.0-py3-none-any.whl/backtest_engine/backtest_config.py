from .backtest import run_backtest
from .simulation import run_simulation
from .plot import plot_simulation
from tqdm import tqdm

class BuildStrategy():
    _symbols = None
    _strategy_repos = None
    _collection = None
    def __init__(self, symbols, strategy_repos, collection):
        self._symbols = symbols
        self._strategy_repos = strategy_repos
        self._collection = collection
        
    def run(self, config):
        backtest_result = {
        }
        i = 0
        for i in tqdm(range(len(self._symbols))):
            symbol = self._symbols[i]
            i+=1
            
            data = self._collection.get_collections()
            df = data[symbol]["data"]
            
            config["default_config"]["symbol_info"] = data[symbol]["symbol_info"]
            config["default_config"]["symbol_info"]["pip_point"] = data[symbol]["symbol_info"]["pip_size"]
            
            default_config = config["default_config"]

            
            for strategy in self._strategy_repos:
                if len(strategy) not in (2, 3):
                    raise ValueError(
                        "Each strategy must be a (name, entry_signal) or "
                        "(name, entry_signal, exit_signal) tuple"
                    )

                signal_name, get_signal = strategy[:2]
                exit_signal = strategy[2] if len(strategy) == 3 else None

                if default_config.get("sl_type") == "custom" and not callable(exit_signal):
                    raise ValueError(
                        f"Custom SL strategy '{signal_name}' requires a callable "
                        "exit signal as the third tuple item"
                    )

                default_config["get_signal"] = get_signal
                default_config["exit_signal"] = exit_signal
            
                backtest_trades = run_backtest(df, default_config)
                
                risk_config = config["risk_config"]
                
                sim_df, report = run_simulation(
                    trades      = backtest_trades,
                    risk_config = risk_config,
                    symbol_info = default_config["symbol_info"]
                )
                
                backtest_result.setdefault(symbol, [])
                
                report["trade_log"] = sim_df
                
                backtest_result[symbol].append(
                    {
                        "report": report,
                        "name": signal_name,
                    }
                )
                
                # plot_simulation(sim_df, report, symbol, signal_name)
                
        return backtest_result