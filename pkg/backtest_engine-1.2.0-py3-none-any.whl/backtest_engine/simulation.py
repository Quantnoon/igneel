import pandas as pd
import numpy as np
from datetime import datetime, time

risk_config = {
    "starting_balance": 10000,
    "currency": "USD",          # "USD" or "NGN"
    "ngn_conversion_rate": 1450,
    "lot_size": 0.01,
    "allow_trading_session": ["london", "newyork"],  # empty [] = allow all
}

SESSIONS = {
    "asian":                  (time(0, 0),  time(9, 0)),
    "london":                 (time(7, 0),  time(16, 0)),
    "newyork":                (time(13, 0), time(21, 0)),
    "london_newyork_overlap": (time(13, 0), time(16, 0)),
}

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]


def get_session(dt: datetime) -> str:
    t = dt.time()
    for session in ["london_newyork_overlap", "asian", "london", "newyork"]:
        start, end = SESSIONS[session]
        if start <= t <= end:
            return session
    return "off_session"


def convert_currency(amount: float, currency: str, rate: float) -> float:
    if currency == "NGN":
        return round(amount * rate, 2)
    return round(amount, 2)


def _normalize_pct(value):
    if value is None:
        return None
    try:
        pct = float(value)
    except (TypeError, ValueError):
        return None
    if pct <= 0:
        return None
    return pct * 100 if pct <= 1 else pct


def run_simulation(trades: pd.DataFrame, risk_config: dict, symbol_info: dict) -> tuple[pd.DataFrame, dict]:
    trades = trades.copy()
    if trades is None or trades.empty:
        print("⚠️ No trades generated — skipping simulation")
    
        # return safe defaults
        sim_df = pd.DataFrame()
        report = {}
        return sim_df, report
    
    trades["open_time"]  = pd.to_datetime(trades["open_time"],  utc=True)
    trades["close_time"] = pd.to_datetime(trades["close_time"], utc=True)
    trades = trades.sort_values("open_time").reset_index(drop=True)

    pip_point      = symbol_info["pip_point"]
    pip_value      = symbol_info["pip_value"]
    lot_size       = risk_config["lot_size"]
    currency       = risk_config["currency"]
    conv_rate      = risk_config.get("ngn_conversion_rate", 1450)
    allow_sessions = risk_config["allow_trading_session"]
    allowed_days   = risk_config.get("trading_days", [])
    daily_dd_limit = _normalize_pct(risk_config.get("daily_dd"))
    max_dd_limit   = _normalize_pct(risk_config.get("maximum_dd"))
    balance        = risk_config["starting_balance"]
    peak_balance   = balance

    simulated = []
    current_day = None
    day_start_balance = balance
    daily_dd_blocked = False
    max_dd_blocked = False

    for _, trade in trades.iterrows():
        open_time = trade["open_time"]
        session   = get_session(open_time.to_pydatetime())
        day_name  = DAYS[open_time.weekday()]
        trade_day = open_time.date()

        if current_day != trade_day:
            current_day = trade_day
            day_start_balance = balance
            daily_dd_blocked = False

        # session filter
        if allow_sessions and session not in allow_sessions:
            simulated.append({
                **trade,
                "pnl_dollar":     0,
                "pnl_currency":   0,
                "balance_before": round(balance, 2),
                "balance_after":  round(balance, 2),
                "session":        session,
                "day":            day_name,
                "skipped":        True,
                "skip_reason":    f"session_not_allowed ({session})",
            })
            continue

        # trading day filter
        if allowed_days and day_name not in allowed_days:
            simulated.append({
                **trade,
                "pnl_dollar":     0,
                "pnl_currency":   0,
                "balance_before": round(balance, 2),
                "balance_after":  round(balance, 2),
                "session":        session,
                "day":            day_name,
                "skipped":        True,
                "skip_reason":    f"trading_day_not_allowed ({day_name})",
            })
            continue

        if max_dd_blocked:
            simulated.append({
                **trade,
                "pnl_dollar":     0,
                "pnl_currency":   0,
                "balance_before": round(balance, 2),
                "balance_after":  round(balance, 2),
                "session":        session,
                "day":            day_name,
                "skipped":        True,
                "skip_reason":    "maximum_dd_reached",
            })
            continue

        if daily_dd_blocked:
            simulated.append({
                **trade,
                "pnl_dollar":     0,
                "pnl_currency":   0,
                "balance_before": round(balance, 2),
                "balance_after":  round(balance, 2),
                "session":        session,
                "day":            day_name,
                "skipped":        True,
                "skip_reason":    "daily_dd_reached",
            })
            continue

        # pnl calculation
        # pnl (price) -> pips -> dollar -> currency
        pnl_price  = trade["pnl"]                          # e.g 0.00500
        pnl_pips   = pnl_price / pip_point                 # e.g 50 pips
        pnl_dollar = round(pnl_pips * pip_value * lot_size, 2)  # e.g $5.00
        pnl_curr   = convert_currency(pnl_dollar, currency, conv_rate)

        balance_before = balance
        balance        = round(balance + pnl_dollar, 2)
        peak_balance   = max(peak_balance, balance)

        if daily_dd_limit is not None and day_start_balance > 0:
            daily_dd = ((day_start_balance - balance) / day_start_balance) * 100
            if daily_dd >= daily_dd_limit:
                daily_dd_blocked = True

        if max_dd_limit is not None and peak_balance > 0:
            max_dd = ((peak_balance - balance) / peak_balance) * 100
            if max_dd >= max_dd_limit:
                max_dd_blocked = True

        simulated.append({
            **trade,
            "pnl_dollar":     pnl_dollar,
            "pnl_currency":   pnl_curr,
            "balance_before": round(balance_before, 2),
            "balance_after":  balance,
            "session":        session,
            "day":            day_name,
            "skipped":        False,
            "skip_reason":    None,
        })

    sim_df = pd.DataFrame(simulated)
    sim_df["lot_size"] = lot_size
    report = _build_report(sim_df, risk_config, balance, peak_balance, currency, conv_rate)

    return sim_df, report


def _build_report(
    df: pd.DataFrame,
    risk_config: dict,
    final_balance: float,
    peak_balance: float,
    currency: str,
    conv_rate: float,
) -> dict:
    taken   = df[df["skipped"] == False].copy()
    skipped = df[df["skipped"] == True].copy()

    wins   = taken[taken["result"] == "win"]
    losses = taken[taken["result"] == "loss"]

    starting_balance = risk_config["starting_balance"]

    total_return  = round(((final_balance - starting_balance) / starting_balance) * 100, 2)

    max_drawdown = 0
    if len(taken):
        peak = starting_balance
        for value in taken["balance_after"]:
            if value > peak:
                peak = value
            if peak > 0:
                drawdown = ((peak - value) / peak) * 100
                if drawdown > max_drawdown:
                    max_drawdown = drawdown
        max_drawdown = round(max_drawdown, 2)

    gross_profit  = round(wins["pnl_dollar"].sum(), 2)
    gross_loss    = round(abs(losses["pnl_dollar"].sum()), 2)
    profit_factor = round(gross_profit / gross_loss, 2) if gross_loss != 0 else float("inf")

    avg_win  = round(wins["pnl_dollar"].mean(), 2)   if len(wins)   else 0
    avg_loss = round(losses["pnl_dollar"].mean(), 2) if len(losses) else 0

    # ── Sharpe & Sortino ─────────────────────────────────────────────────
    # using pnl_dollar per trade as returns, risk_free = 0
    returns = taken["pnl_dollar"]

    if len(returns) > 1 and returns.std() != 0:
        sharpe = round(returns.mean() / returns.std(), 3)
    else:
        sharpe = 0.0

    downside_returns = returns[returns < 0]
    if len(downside_returns) > 1 and downside_returns.std() != 0:
        sortino = round(returns.mean() / downside_returns.std(), 3)
    else:
        sortino = 0.0

    # session breakdown
    session_breakdown = (
        taken.groupby("session")
             .agg(
                 trades=("result",        "count"),
                 wins=("result",          lambda x: (x == "win").sum()),
                 losses=("result",        lambda x: (x == "loss").sum()),
                 pnl_dollar=("pnl_dollar","sum"),
             )
             .round(2)
             .to_dict(orient="index")
    )

    # day of week breakdown
    day_order    = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    taken["day"] = pd.Categorical(taken["day"], categories=day_order, ordered=True)
    day_breakdown = (
        taken.groupby("day", observed=True)
             .agg(
                 trades=("result",        "count"),
                 wins=("result",          lambda x: (x == "win").sum()),
                 losses=("result",        lambda x: (x == "loss").sum()),
                 pnl_dollar=("pnl_dollar","sum"),
             )
             .round(2)
             .to_dict(orient="index")
    )

    skip_breakdown = skipped["skip_reason"].value_counts().to_dict() if len(skipped) else {}

    def fmt(amount):
        converted = convert_currency(amount, currency, conv_rate)
        symbol    = "₦" if currency == "NGN" else "$"
        return f"{symbol}{converted:,.2f}"

    return {
        "currency":           currency,
        "starting_balance":   fmt(starting_balance),
        "final_balance":      fmt(final_balance),
        "total_return_pct":   f"{total_return}%",
        "max_drawdown_pct":   f"{max_drawdown}%",
        "peak_balance":       fmt(peak_balance),
        "trades_taken":       len(taken),
        "trades_skipped":     len(skipped),
        "win_rate_pct":       f"{round(len(wins) / len(taken) * 100, 2)}%" if len(taken) else "0%",
        "profit_factor":      profit_factor,
        "sharpe_ratio":       sharpe,
        "sortino_ratio":      sortino,
        "avg_win":            fmt(avg_win),
        "avg_loss":           fmt(avg_loss),
        "gross_profit":       fmt(gross_profit),
        "gross_loss":         fmt(gross_loss),
        "skip_breakdown":     skip_breakdown,
        "session_breakdown":  session_breakdown,
        "day_breakdown":      day_breakdown,
    }
