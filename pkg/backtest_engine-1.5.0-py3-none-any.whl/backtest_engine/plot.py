import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import numpy as np
import pandas as pd


def plot_simulation(sim_df: pd.DataFrame, report: dict, pSymbol: str, signal_name: str):
    if sim_df is None or sim_df.empty:
        print("⚠️ No trades generated — skipping plot simulation")
        return

    taken   = sim_df[sim_df["skipped"] == False].copy()
    currency = report["currency"]
    symbol   = "₦" if currency == "NGN" else "$"
    pnl_col  = "pnl_currency" if currency == "NGN" else "pnl_dollar"

    fig = plt.figure(figsize=(18, 16))
    fig.suptitle(f"({pSymbol} - {signal_name}) - Simulation Report",
                 fontsize=16, fontweight="bold", y=0.98)

    # ✅ 5 rows now (last 2 rows for table)
    gs = gridspec.GridSpec(5, 2, figure=fig, hspace=0.6, wspace=0.35)

    # ── 1. Balance Growth ───────────────────────────────────────────────
    ax1 = fig.add_subplot(gs[0, :])
    balance_col = "balance_after"

    if currency == "NGN":
        rate = 1450
        balance_series = taken[balance_col] * rate
    else:
        balance_series = taken[balance_col]

    ax1.plot(range(len(taken)), balance_series, linewidth=1.5)
    ax1.fill_between(range(len(taken)), balance_series,
                     balance_series.min(), alpha=0.1)
    ax1.axhline(balance_series.iloc[0], linestyle="--",
                linewidth=0.8, label="Starting balance")

    ax1.set_title("Balance Growth")
    ax1.set_xlabel("Trade #")
    ax1.set_ylabel(f"Balance ({currency})")
    ax1.legend()
    ax1.yaxis.set_major_formatter(
        plt.FuncFormatter(lambda x, _: f"{symbol}{x:,.0f}")
    )
    ax1.grid(True, alpha=0.3)

    # ── 2. Drawdown ──────────────────────────────────────────────────────
    ax2 = fig.add_subplot(gs[1, :])

    bal = balance_series
    running_peak = bal.cummax()
    drawdown_pct = ((bal - running_peak) / running_peak) * 100

    ax2.fill_between(range(len(taken)), drawdown_pct, 0, alpha=0.6)
    ax2.plot(range(len(taken)), drawdown_pct, linewidth=1)

    ax2.set_title("Drawdown %")
    ax2.set_xlabel("Trade #")
    ax2.set_ylabel("Drawdown (%)")
    ax2.yaxis.set_major_formatter(
        plt.FuncFormatter(lambda x, _: f"{x:.1f}%")
    )
    ax2.grid(True, alpha=0.3)

    # ── 3. Trades by Day ─────────────────────────────────────────────────
    ax3 = fig.add_subplot(gs[2, 0])

    day_order = ["Monday", "Tuesday", "Wednesday", "Thursday",
                 "Friday", "Saturday", "Sunday"]

    taken["day"] = pd.Categorical(taken["day"],
                                 categories=day_order, ordered=True)

    day_grp  = taken.groupby("day", observed=True)
    day_wins = day_grp.apply(lambda x: (x["result"] == "win").sum())
    day_loss = day_grp.apply(lambda x: (x["result"] == "loss").sum())

    x = np.arange(len(day_order))
    width = 0.35

    bars_w = ax3.bar(x - width/2,
                     day_wins.reindex(day_order).fillna(0),
                     width, label="Win", alpha=0.85)

    bars_l = ax3.bar(x + width/2,
                     day_loss.reindex(day_order).fillna(0),
                     width, label="Loss", alpha=0.85)

    ax3.set_title("Trades by Day")
    ax3.set_xticks(x)
    ax3.set_xticklabels([d[:3] for d in day_order])
    ax3.legend()
    ax3.grid(True, axis="y", alpha=0.3)

    # ── 4. Trades by Session ─────────────────────────────────────────────
    ax4 = fig.add_subplot(gs[2, 1])

    session_order = ["asian", "london",
                     "london_newyork_overlap", "newyork", "off_session"]

    sess_grp = taken.groupby("session")
    sess_wins = sess_grp.apply(lambda x: (x["result"] == "win").sum())
    sess_loss = sess_grp.apply(lambda x: (x["result"] == "loss").sum())

    x2 = np.arange(len(session_order))

    ax4.bar(x2 - width/2,
            sess_wins.reindex(session_order).fillna(0),
            width, label="Win", alpha=0.85)

    ax4.bar(x2 + width/2,
            sess_loss.reindex(session_order).fillna(0),
            width, label="Loss", alpha=0.85)

    ax4.set_title("Trades by Session")
    ax4.set_xticks(x2)
    ax4.set_xticklabels(["Asian", "London", "Overlap", "NY", "Off"], fontsize=8)
    ax4.legend()
    ax4.grid(True, axis="y", alpha=0.3)

    # ── 5. Summary Table (BOTTOM, FULL WIDTH) ────────────────────────────
    ax5 = fig.add_subplot(gs[3:, :])  # spans last 2 rows
    ax5.axis('off')

    main_metrics = [
        ("Currency", report["currency"]),
        ("Starting Balance", report["starting_balance"]),
        ("Final Balance", report["final_balance"]),
        ("Peak Balance", report["peak_balance"]),
        ("Return (%)", report["total_return_pct"]),
        ("Max Drawdown (%)", report["max_drawdown_pct"]),
    ]

    trade_metrics = [
        ("Trades Taken", report["trades_taken"]),
        ("Trades Skipped", report["trades_skipped"]),
        ("Win Rate (%)", report["win_rate_pct"]),
    ]

    risk_metrics = [
        ("Profit Factor", report["profit_factor"]),
        ("Sharpe Ratio", report["sharpe_ratio"]),
        ("Sortino Ratio", report["sortino_ratio"]),
    ]

    profit_metrics = [
        ("Avg Win", report["avg_win"]),
        ("Avg Loss", report["avg_loss"]),
        ("Gross Profit", report["gross_profit"]),
        ("Gross Loss", report["gross_loss"]),
    ]

    table_data = [["Metric", "Value"]]

    for section in [main_metrics, trade_metrics, risk_metrics, profit_metrics]:
        for metric, value in section:
            table_data.append([metric, value])

    table = ax5.table(
        cellText=table_data,
        loc="center",
        cellLoc="left"
    )

    table.auto_set_font_size(False)
    table.set_fontsize(10)
    table.scale(1, 1.6)

    # Header styling
    for (row, col), cell in table.get_celld().items():
        if row == 0:
            cell.set_text_props(weight='bold')

    plt.tight_layout()
    plt.show()