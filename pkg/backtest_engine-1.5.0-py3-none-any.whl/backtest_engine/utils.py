
from datetime import datetime, time, timedelta
from zoneinfo import ZoneInfo
import pandas as pd

def merge_timeframes(dfs: dict, base_tf: str) -> pd.DataFrame:
    def clean(df, tf):
        df = df.copy()
    
        # 🔥 If time is index → move it safely
        if 'time' not in df.columns:
            df = df.reset_index()
    
        # 🚨 Remove index completely to avoid ambiguity
        df = df.reset_index(drop=True)
    
        # Ensure correct column name
        if 'time' not in df.columns:
            for col in ['Time', 'datetime', 'date']:
                if col in df.columns:
                    df = df.rename(columns={col: 'time'})
                    break
    
        if 'time' not in df.columns:
            raise ValueError(f"{tf} has no time column")
    
        df['time'] = pd.to_datetime(df['time'])
    
        df = df.loc[:, ~df.columns.duplicated()]
        df = df.sort_values('time').reset_index(drop=True)
    
        df = df.add_suffix(f'_{tf}').rename(columns={f'time_{tf}': 'time'})
    
        return df

    result = clean(dfs[base_tf], base_tf)

    for tf, df in dfs.items():
        if tf == base_tf:
            continue

        df = clean(df, tf)

        result = pd.merge_asof(
            result,
            df,
            on='time',
            direction='backward'
        )

    return result

TRADING_SESSIONS = {
    "asian": {
        "tz": "Asia/Tokyo",
        "start": time(9, 0),
        "end":   time(18, 0),
    },

    "london": {
        "tz": "Europe/London",
        "start": time(8, 0),
        "end":   time(16, 30),
    },

    "new_york": {
        "tz": "America/New_York",
        "start": time(8, 30),
        "end":   time(17, 0),
    },
}

TRADING_DAYS = [
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
    "Sunday"
]

# ============================================================
# Core: Get session window in UTC
# ============================================================
def _session_window_utc(session: dict, reference_utc: datetime):
    tz = ZoneInfo(session["tz"])
    local_now = reference_utc.astimezone(tz)

    local_start = datetime.combine(local_now.date(), session["start"], tz)
    local_end   = datetime.combine(local_now.date(), session["end"], tz)

    # Handle overnight sessions (not used here, but safe)
    if session["end"] <= session["start"]:
        local_end += timedelta(days=1)

    return (
        local_start.astimezone(ZoneInfo("UTC")),
        local_end.astimezone(ZoneInfo("UTC")),
    )

# ============================================================
# Dynamic Overlap (NO HARDCODING)
# ============================================================
def _get_overlap_window(reference_utc: datetime):
    london = TRADING_SESSIONS["london"]
    ny     = TRADING_SESSIONS["new_york"]

    l_start, l_end = _session_window_utc(london, reference_utc)
    n_start, n_end = _session_window_utc(ny, reference_utc)

    overlap_start = max(l_start, n_start)
    overlap_end   = min(l_end, n_end)

    return overlap_start, overlap_end

# ============================================================
# Check if inside any session
# ============================================================
def is_in_any_session(session_list: list[str]):
    now_utc = datetime.now(ZoneInfo("UTC"))

    for name in session_list:

        # 🔥 Handle overlap separately
        if name in {"london_new_york_overlap", "new_york_london_overlap"}:
            start, end = _get_overlap_window(now_utc)
        else:
            session = TRADING_SESSIONS.get(name)
            if not session:
                raise ValueError(f"Unknown session: {name}")
            start, end = _session_window_utc(session, now_utc)

        if start <= now_utc <= end:
            return True, name

    return False, None


def is_trading_day(days_list, date_input):
    """
    Check if the given date's weekday is in the allowed days list.

    Args:
        days_list (list): List of allowed day names, e.g. ["Monday", "Tuesday"]
        date_input (str | datetime): Date string or datetime object

    Returns:
        bool: True if date's day is in days_list, else False
    """
    
    # Convert string to datetime if needed
    if isinstance(date_input, str):
        date_input = pd.to_datetime(date_input)

    # Get full weekday name
    day_name = date_input.strftime("%A")

    return day_name in days_list
