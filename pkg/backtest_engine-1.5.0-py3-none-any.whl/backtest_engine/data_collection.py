
class DataCollection:
    _collections = {}
    def __init__(self, price_data, symbols):
        for symbol in symbols:
            df = price_data.get_price_data(symbol)
            self._collections[symbol] = {
                "data": df,
                "symbol_info": price_data.get_symbol_info(symbol)
            }
    
    def get_collections(self, symbol=None):
        if symbol is not None:
            return self._collections[symbol]
        return self._collections


