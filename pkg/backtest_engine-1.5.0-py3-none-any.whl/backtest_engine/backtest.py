import pandas as pd
import numpy as np

default_config = {
    "sl_type": "atr",
    "fixed_amount": 15,
    "atr_multiplier": 1.5,
    "structure_range": 10,
    "rrr": 2.0,
    "entry_tf": "M15",
    "symbol_info": {
        "pip_point": 0.0001,
        "pip_value": 1.0,
    },
}

def calculate_sl(df, i, signal, config):
    sl_type   = config["sl_type"]
    pip_point = config["symbol_info"]["pip_point"]
    pip_value = config["symbol_info"]["pip_value"]
    tf        = config["entry_tf"]
    entry     = df.at[i, f"close_{tf}"]
    slippage = config["slippage"] * pip_point

    if sl_type == "fixed_amount":
        distance = (config["fixed_amount"] / pip_value) * pip_point
        return (entry - distance) + slippage if signal == "buy" else (entry + distance) - slippage

    elif sl_type == "atr":
        atr_col  = f"atr_{tf}"
        atr      = df.at[i, atr_col] if atr_col in df.columns else _calc_atr(df, i, tf)
        distance = atr * config["atr_multiplier"]
        return (entry - distance) + slippage if signal == "buy" else (entry + distance) - slippage

    elif sl_type == "structure":
        lookback  = config["structure_range"]
        start     = max(0, i - lookback)
        low_col   = f"low_{tf}"
        high_col  = f"high_{tf}"

        if signal == "buy":
            return min(df[low_col].values[start:i + 1])
        else:
            return max(df[high_col].values[start:i + 1])

    return None


def _calc_atr(df, i, tf, period=14):
    start      = max(0, i - period)
    high_col   = f"high_{tf}"
    low_col    = f"low_{tf}"
    close_col  = f"close_{tf}"
    highs      = df[high_col].values[start:i + 1]
    lows       = df[low_col].values[start:i + 1]
    closes     = df[close_col].values[start:i + 1]
    trs = [
        max(highs[j] - lows[j], abs(highs[j] - closes[j - 1]), abs(lows[j] - closes[j - 1]))
        for j in range(1, len(highs))
    ]
    return np.mean(trs) if trs else highs[-1] - lows[-1]


def run_backtest(df, config=default_config):
    df      = df.reset_index(drop=True)
    tf      = config["entry_tf"]
    sl_type = config["sl_type"]
    closes  = df[f"close_{tf}"].values
    highs   = df[f"high_{tf}"].values
    lows    = df[f"low_{tf}"].values
    times   = df["time"].values if "time" in df.columns else df.index.values
    
    get_signal = config["get_signal"]
    exit_signal = config.get("exit_signal")

    if sl_type == "custom" and not callable(exit_signal):
        raise ValueError(
            "Custom SL strategies require a callable exit signal as the third "
            "strategy tuple item"
        )

    open_trades   = []
    closed_trades = []

    for i in range(len(df)):
        current_close = closes[i]
        current_high  = highs[i]
        current_low   = lows[i]
        current_time  = times[i]

        for trade in open_trades[:]:
            if sl_type == "custom":
                if not exit_signal(df, i, trade["position"]):
                    continue

                exit_price = current_close
                pnl = (
                    exit_price - trade["entry"]
                    if trade["position"] == "buy"
                    else trade["entry"] - exit_price
                )
                result = "win" if pnl > 0 else "loss" if pnl < 0 else "breakeven"

                closed_trades.append({
                    "position":   trade["position"],
                    "entry":      trade["entry"],
                    "exit":       exit_price,
                    "sl":         trade["sl"],
                    "tp":         trade["tp"],
                    "open_time":  trade["open_time"],
                    "close_time": current_time,
                    "result":     result,
                    "pnl":        round(pnl, 5),
                })
                open_trades.remove(trade)
                continue

            hit_sl = False
            hit_tp = False

            if trade["position"] == "buy":
                hit_sl = current_low  <= trade["sl"]
                hit_tp = current_high >= trade["tp"]
            else:
                hit_sl = current_high >= trade["sl"]
                hit_tp = current_low  <= trade["tp"]

            if hit_tp or hit_sl:
                exit_price = trade["tp"] if hit_tp else trade["sl"]
                result     = "win" if hit_tp else "loss"
                pnl        = exit_price - trade["entry"] if trade["position"] == "buy" else trade["entry"] - exit_price

                closed_trades.append({
                    "position":   trade["position"],
                    "entry":      trade["entry"],
                    "exit":       exit_price,
                    "sl":         trade["sl"],
                    "tp":         trade["tp"],
                    "open_time":  trade["open_time"],
                    "close_time": current_time,
                    "result":     result,
                    "pnl":        round(pnl, 5),
                })
                open_trades.remove(trade)

        signal = get_signal(df, i)

        if signal is None:
            continue

        has_buy  = any(t["position"] == "buy"  for t in open_trades)
        has_sell = any(t["position"] == "sell" for t in open_trades)

        if signal == "buy"  and has_buy:
            continue
        if signal == "sell" and has_sell:
            continue
        if (has_buy or has_sell):
            continue

        entry   = current_close

        if sl_type == "custom":
            sl = None
            tp = None
        else:
            sl = calculate_sl(df, i, signal, config)
            if sl is None:
                continue

            sl_dist = abs(entry - sl)
            tp_dist = sl_dist * config["rrr"]
            tp      = entry + tp_dist if signal == "buy" else entry - tp_dist

        open_trades.append({
            "position":  signal,
            "entry":     entry,
            "sl":        sl,
            "tp":        tp,
            "open_time": current_time,
        })

    for trade in open_trades:
        exit_price = closes[-1]
        pnl        = exit_price - trade["entry"] if trade["position"] == "buy" else trade["entry"] - exit_price

        closed_trades.append({
            "position":   trade["position"],
            "entry":      trade["entry"],
            "exit":       exit_price,
            "sl":         trade["sl"],
            "tp":         trade["tp"],
            "open_time":  trade["open_time"],
            "close_time": times[-1],
            "result":     "open",
            "pnl":        round(pnl, 5),
        })

    return pd.DataFrame(closed_trades)
