def m15_structure_change(df, i):
    required_cols = [
        "supply_high_H1",
        "supply_low_H1",
        "demand_high_H1",
        "demand_low_H1",
        "ema_trend_M15",
        "slope_trend_M15",
        "close_M15",
    ]
    for col in required_cols:
        if col not in df.columns:
            return None

    supply_high = df["supply_high_H1"].values
    supply_low = df["supply_low_H1"].values
    demand_high = df["demand_high_H1"].values
    demand_low = df["demand_low_H1"].values
    ema_trend = df["ema_trend_M15"].values
    slope_trend = df["slope_trend_M15"].values
    entry = df["close_M15"].values

    if (
        ema_trend[i] < entry[i] or slope_trend[i] == "up"
    ):
        return 1

    if (
        ema_trend[i] > entry[i] or slope_trend[i] == "down"
    ):
        return 2

    return None

def m15_breakout(df, i):
    required_cols = [
        "supply_high_H1",
        "supply_low_H1",
        "demand_high_H1",
        "demand_low_H1",
        "ema_trend_M15",
        "slope_trend_M15",
        "close_M15",
    ]
    for col in required_cols:
        if col not in df.columns:
            return None

    supply_high = df["supply_high_H1"].values
    supply_low = df["supply_low_H1"].values
    demand_high = df["demand_high_H1"].values
    demand_low = df["demand_low_H1"].values
    ema_trend = df["ema_trend_M15"].values
    slope_trend = df["slope_trend_M15"].values
    entry = df["close_M15"].values

    if (supply_high[i] > entry[i] > supply_low[i]) and (
        ema_trend[i] < entry[i] or slope_trend[i] == "up"
    ):
        return 1

    if (demand_high[i] > entry[i] > demand_low[i]) and (
        ema_trend[i] > entry[i] or slope_trend[i] == "down"
    ):
        return 2

    return None


def _normalize_signal(position):
    return {1: "buy", 2: "sell"}.get(position, None)


def _set_signal(signal):
    def get_signal(df, index):
        return _normalize_signal(signal(df, index))

    return get_signal

def exit_signal(df, index, pos):
    slope_trend = df["slope_trend_M15"].values

    if pos == "buy" and slope_trend[index] == "down":
        return True
    elif pos == "sell" and slope_trend[index] == "up":
        return True
    else:
        return False

strategy_list = [
    ("m15_structure_change", _set_signal(m15_structure_change), exit_signal),
    ("m15_breakout", _set_signal(m15_breakout), exit_signal)
]