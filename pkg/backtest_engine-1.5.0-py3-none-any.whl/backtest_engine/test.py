import MetaTrader5 as mt5
from price_data.price_data import MT5PriceData

from strategy_list import strategy_list
from main import Engine


if not mt5.initialize():
    print(f"MT5 initialize failed: {mt5.last_error()}")
    raise SystemExit(1)


price_data = MT5PriceData(mt5)

symbols = ["GBPUSDm", "USDJPYm"]

timeframes = ["D1", "W1", "H1", "M15", "M5"]

indicators = [
    {
         "name": "DEMAND_ZONE",
         "indicator": "DEMAND_ZONE",
         "timeframe": "H1",
         "params": {
             "sd_lookback": 12
        }
    },
    {
         "name": "SUPPLY_ZONE",
         "indicator": "SUPPLY_ZONE",
         "timeframe": "H1",
         "params": {
             "sd_lookback": 12
        }
    },
    {
         "name": "SLOPE_TREND",
         "indicator": "SLOPE_TREND",
         "timeframe": "M15",
    },
    {
         "name": "EMA_TREND",
         "indicator": "EMA_TREND",
         "timeframe": "M15",
    }
]

config = {
    "default_config": {
        "sl_type": "atr", # "custom ",
        "atr_multiplier": 1.5,
        "rrr": 2,
        "entry_tf": "M15",
        "slippage": 2.5
    },
    "risk_config": {
        "starting_balance":      50,
        "currency":              "USD",   # or "NGN"
        "ngn_conversion_rate":   1450,
        "lot_size":              0.01,
        "allow_trading_session": [],  # ["asian", "newyork", "london_newyork_overlap", "london"] = all sessions,
        "daily_dd": 0.05, # in percentage
        "maximum_dd": 0.7, # in percentage
        "trading_days": [], # [] = all trading days
    }
}

engine = Engine(price_data, symbols, timeframes, indicators, "1M")

engine.set_config(config, strategy_list)

result = engine.run_backtest()

