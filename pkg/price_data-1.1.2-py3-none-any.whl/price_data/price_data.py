from abc import abstractmethod, ABC
import pandas as pd
from .helpers import get_pip, get_pip_value, get_time_range, get_mt5_timeframe, merge_timeframes
from collections import defaultdict
from technical_indicator.indicators import set_indicators

class PriceData(ABC):
    _prices = None
    _symbols = []
    _timeframes = []

    @abstractmethod
    def set_price(self, symbols, date_range, timeframes):
        pass

    def get_price(self, symbol, timeframe=None):
        if timeframe is None:
            return self._prices[symbol]["prices"]
        return self._prices[symbol]["prices"].get(timeframe)

    def get_symbol_info(self, symbol):
        return self._prices[symbol].get("info")

    def get_merged_price(self, symbol):
        if not self._timeframes:
            return None

        timeframes = [tf for tf in self._timeframes if tf]
        if not timeframes:
            return None

        timeframe = min(
            timeframes,
            key=lambda x: ["M1", "M5", "M15", "H1", "H4", "D1", "W1"].index(x.upper()),
        )
        return merge_timeframes(self._prices[symbol]["prices"], timeframe)

    def set_indicator(self, indicators):
        for symbol in self._symbols:
            self._prices[symbol]["prices"] = set_indicators(indicators, self.get_price(symbol))

class MT5PriceData(PriceData):
    __mt5 = None

    def __init__(self, mt5):
        self.__mt5 = mt5
        self._prices = defaultdict(lambda: defaultdict(dict))

    def set_price(self, symbols, date_range, timeframes):
        self._timeframes = timeframes
        self._symbols = symbols  # ✅ was _symbols, missing self
        start, end = get_time_range(date_range)

        for symbol in symbols:
            if not self.__mt5.symbol_select(symbol, True):
                print(f"  [DATA] Failed to select symbol {symbol}: {self.__mt5.last_error()}")
                continue  # ✅ continue to next symbol instead of stopping everything

            self._prices[symbol]["info"] = {
                "pip_size": get_pip(self.__mt5, symbol),
                "pip_value": get_pip_value(self.__mt5, symbol),
                "tick_size": self.__mt5.symbol_info(symbol).trade_tick_size,
                "tick_value": self.__mt5.symbol_info(symbol).trade_tick_value,
            }

            for timeframe in timeframes:
                tf = get_mt5_timeframe(self.__mt5, timeframe.upper())
                if tf is None:
                    print(f"  [DATA] Unknown timeframe: {timeframe}")
                    continue  # ✅ continue to next timeframe instead of stopping

                ticks = self.__mt5.copy_ticks_range(symbol, start, end, self.__mt5.COPY_TICKS_ALL)
                tick_df = pd.DataFrame([])
                if ticks is not None and len(ticks) > 0:
                    tick_df = pd.DataFrame(ticks)
                    tick_df['time'] = pd.to_datetime(tick_df['time'], unit='s', utc=True)
                    tick_df = tick_df.sort_values('time')

                rates = self.__mt5.copy_rates_range(symbol, tf, start, end)
                if rates is None or len(rates) == 0:
                    print(f"  [DATA] No data: {symbol} {timeframe} — {self.__mt5.last_error()}")
                    continue  # ✅ continue to next timeframe instead of stopping

                df = pd.DataFrame(rates)
                df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
                df = df.set_index("time")
                df = df.rename(columns={"tick_volume": "volume"})
                df = df[["open", "high", "low", "close", "volume"]]

                if tick_df.size > 1:
                    df = pd.merge_asof(df, tick_df[['time', 'bid', 'ask']], on='time', direction='backward')

                self._prices[symbol]["prices"][timeframe] = df # ✅ set directly, no need for two lines

        print(f"  [DATA] Loaded {len(self._symbols)} symbols: {self._symbols}")