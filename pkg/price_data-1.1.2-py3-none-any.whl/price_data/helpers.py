from dateutil.relativedelta import relativedelta
import pytz
from datetime import datetime, time, timedelta
from zoneinfo import ZoneInfo
import pandas as pd

def get_time_range(offset_str):
    """
    Returns (start_time, end_time) in UTC.

    Supported offset_str:
    - '5M' = 5 months
    - '3H' = 3 hours
    - '10D' = 10 days
    - '2W' = 2 weeks
    - '1Y' = 1 year

    start_time is set to 00:00:00
    end_time is current UTC time
    """
    tz = pytz.utc
    now = datetime.now(tz)

    unit = offset_str[-1].upper()
    value = int(offset_str[:-1])

    if unit == "M":
        delta = relativedelta(months=value)
    elif unit == "Y":
        delta = relativedelta(years=value)
    elif unit == "W":
        delta = timedelta(weeks=value)
    elif unit == "D":
        delta = timedelta(days=value)
    else:
        raise ValueError(f"Unsupported time unit '{unit}' in '{offset_str}'")

    start_dt = now - delta

    # Set time to midnight
    start_time = datetime(start_dt.year, start_dt.month, start_dt.day, 0, 0, 0, tzinfo=tz)
    end_time = now

    return start_time, end_time


def get_mt5_timeframe(mt5, tf_string):
    mapping = {
        "W1": mt5.TIMEFRAME_W1,
        "D1": mt5.TIMEFRAME_D1,
        "H4": mt5.TIMEFRAME_H4,
        "H1": mt5.TIMEFRAME_H1,
        "M15": mt5.TIMEFRAME_M15,
        "M5": mt5.TIMEFRAME_M5,
        "M1": mt5.TIMEFRAME_M1
    }
    return mapping.get(tf_string, None)

def get_pip(mt5, symbol):
    return 10*mt5.symbol_info(symbol).point

def get_pip_value(mt5, symbol):
    tick_value = mt5.symbol_info(symbol).trade_tick_value
    tick_size = mt5.symbol_info(symbol).trade_tick_size
    return tick_value / tick_size * get_pip(mt5, symbol)

def merge_timeframes(dfs: dict, base_tf: str) -> pd.DataFrame:
    def clean(df, tf):
        df = df.copy()
    
        # 🔥 If time is index → move it safely
        if 'time' not in df.columns:
            df = df.reset_index()
    
        # 🚨 Remove index completely to avoid ambiguity
        df = df.reset_index(drop=True)
    
        # Ensure correct column name
        if 'time' not in df.columns:
            for col in ['Time', 'datetime', 'date']:
                if col in df.columns:
                    df = df.rename(columns={col: 'time'})
                    break
    
        if 'time' not in df.columns:
            raise ValueError(f"{tf} has no time column")
    
        df['time'] = pd.to_datetime(df['time'])
    
        df = df.loc[:, ~df.columns.duplicated()]
        df = df.sort_values('time').reset_index(drop=True)
    
        df = df.add_suffix(f'_{tf}').rename(columns={f'time_{tf}': 'time'})
    
        return df

    result = clean(dfs[base_tf], base_tf)

    for tf, df in dfs.items():
        if tf == base_tf:
            continue

        df = clean(df, tf)

        result = pd.merge_asof(
            result,
            df,
            on='time',
            direction='backward'
        )

    return result