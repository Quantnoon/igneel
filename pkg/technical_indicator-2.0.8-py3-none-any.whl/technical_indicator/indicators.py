import talib
import numpy as np
import pandas as pd
from datetime import timedelta
from .indicator_registry import INDICATOR_REGISTRY

# ─────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────

def _lookup(key):

    for bucket in INDICATOR_REGISTRY:

        if key in INDICATOR_REGISTRY[bucket]:
            return INDICATOR_REGISTRY[bucket][key], bucket

    return None, None


def _resolve_outputs(cfg, meta):

    outputs = cfg.get("outputs")

    if outputs is None:
        outputs = list(meta["outputs"])

    if not isinstance(outputs, list) or len(outputs) == 0:
        raise IndicatorValidationError(
            f"{cfg['indicator']} outputs must be a non-empty list of strings"
        )

    resolved = []

    for out in outputs:

        if not isinstance(out, str) or not out.strip():
            raise IndicatorValidationError(
                f"{cfg['indicator']} outputs must contain non-empty strings"
            )

        resolved.append(out.strip())

    expected_count = len(meta["outputs"])

    if len(resolved) != expected_count:
        raise IndicatorValidationError(
            f"{cfg['indicator']} expects {expected_count} outputs, got {len(resolved)}"
        )

    return resolved


def _slice_history(completed, lookback_bars=None, lookback_hours=None, ts=None):

    if lookback_hours not in (None, 0):
        cutoff = ts - timedelta(hours=lookback_hours)
        return completed[completed.index >= cutoff]

    if lookback_bars not in (None, 0):
        return completed.iloc[-lookback_bars:]

    return completed


# ─────────────────────────────────────────────
# VALIDATOR
# ─────────────────────────────────────────────

class IndicatorValidationError(Exception):
    pass


class IndicatorValidator:

    def __init__(self, price_data):

        self.price_data = price_data


    def validate(self, cfg):

        key = cfg["indicator"]
        tf  = cfg["timeframe"]

        meta, bucket = _lookup(key)

        if meta is None:
            raise IndicatorValidationError(f"Unknown indicator {key}")

        if tf not in self.price_data:
            raise IndicatorValidationError(f"Timeframe {tf} not found")

        df = self.price_data[tf]

        for col in meta["inputs"]["required"]:

            if col not in df.columns:
                raise IndicatorValidationError(
                    f"{key} requires column {col}"
                )

        if not isinstance(df.index, pd.DatetimeIndex):
            raise IndicatorValidationError(
                "Dataframe must have DatetimeIndex"
            )

        _resolve_outputs(cfg, meta)


# ─────────────────────────────────────────────
# EXECUTOR
# ─────────────────────────────────────────────

class IndicatorExecutor:

    def run(self, df, cfg):

        key = cfg["indicator"]

        meta, bucket = _lookup(key)

        source_df = cfg.get("source_df", df)

        if key == "VOLATILITY_REGIME":
            return self._run_volatility_regime(source_df, cfg, meta)

        if bucket == "indicators":
            return self._run_talib(source_df, cfg, meta)

        if bucket == "candlestick_patterns":
            return self._run_talib(source_df, cfg, meta)

        if bucket == "price_levels":
            return self._run_price_level(df, source_df, cfg, meta)

        if bucket == "fvg":
            return self._run_fvg(df, source_df, cfg, meta)
        
        if bucket == "trends":
            return self._run_trend(df, source_df, cfg, meta)
        
        if bucket == "zones" and meta["detection_method"] == "session":
            return self._run_session_zone(df, cfg, meta)
        
        if bucket == "zones" and meta["detection_method"] == "rolling_hl":
            return self._run_rolling_hl_zone(df, cfg, meta)
        
        if bucket == "zones":
            return self._run_zone(df, source_df, cfg, meta)

        raise ValueError("Unsupported indicator")


    # ─────────────────────────
    
    def _run_zone(self, df, source_df, cfg, meta):
        params = {p: s["default"] for p, s in meta["params"].items()}
        params.update(cfg.get("params", {}))

        key       = cfg["indicator"]
        zone_type = key.replace("_ZONE", "").lower()  # supply | demand | support | resistance

        zones = self._detect_zones(source_df, meta["detection_method"], params)
        candidates_by_end = {}

        for ztype, lo, hi, start_pos, end_pos, score in zones:
            if ztype != zone_type:
                continue
            candidates_by_end.setdefault(end_pos, []).append((lo, hi, start_pos, end_pos, score))

        source_lo = np.full(len(source_df), np.nan)
        source_hi = np.full(len(source_df), np.nan)
        zone_index = params["zone_index"]

        for end_pos, candidates in candidates_by_end.items():
            if end_pos >= len(source_df):
                continue

            price = source_df["close"].iloc[end_pos]
            candidates.sort(
                key=lambda zone: (
                    -zone[4],
                    abs(((zone[0] + zone[1]) / 2) - price),
                )
            )

            if zone_index < len(candidates):
                lo, hi, start_pos, end_pos, _ = candidates[zone_index]
                start_pos = max(0, start_pos)
                end_pos = min(len(source_df) - 1, end_pos)
                source_lo[start_pos:end_pos + 1] = lo
                source_hi[start_pos:end_pos + 1] = hi

        if source_df.index.equals(df.index):
            lo_arr = source_lo
            hi_arr = source_hi
        else:
            selected = pd.DataFrame({"low": source_lo, "high": source_hi}, index=source_df.index)
            selected = selected.reindex(df.index)
            lo_arr = selected["low"].values
            hi_arr = selected["high"].values

        return (lo_arr, hi_arr)

    def _get_supply_demand_lookback(self, params):
        lookback = params.get("sd_lookback", 12)
        return max(int(lookback), 1)

    def _get_supply_demand_reference_start(self, hist, leg_out, params):
        lookback_hours = params.get("sd_lookback_hours", 0)
        if lookback_hours not in (None, 0):
            cutoff = hist.index[leg_out] - timedelta(hours=float(lookback_hours))
            return int(hist.index.searchsorted(cutoff, side="left"))

        lookback = self._get_supply_demand_lookback(params)
        return max(0, leg_out - lookback)

    def _run_talib(self, source_df, cfg, meta):

        func   = getattr(talib, meta["function"])
        inputs = [source_df[col].values for col in meta["inputs"]["required"]]
        params = cfg.get("params", {})
        result = func(*inputs, **params)

        if not isinstance(result, tuple):
            result = (result,)

        return result


    # ─────────────────────────

    def _run_volatility_regime(self, source_df, cfg, meta):
        params = {p: s["default"] for p, s in meta["params"].items()}
        params.update(cfg.get("params", {}))

        timeperiod = max(int(params["timeperiod"]), 1)
        regime_lookback = max(int(params["regime_lookback"]), 2)
        low_percentile = float(params["low_percentile"])
        high_percentile = float(params["high_percentile"])
        if low_percentile > high_percentile:
            low_percentile, high_percentile = high_percentile, low_percentile

        high = source_df["high"].astype(float)
        low = source_df["low"].astype(float)
        close = source_df["close"].astype(float)
        prev_close = close.shift(1)
        true_range = pd.concat(
            [
                high - low,
                (high - prev_close).abs(),
                (low - prev_close).abs(),
            ],
            axis=1,
        ).max(axis=1)

        atr = true_range.rolling(timeperiod, min_periods=timeperiod).mean()
        natr = (atr / close.replace(0, np.nan)) * 100.0
        result = np.full(len(source_df), np.nan)

        for i in range(len(source_df)):
            start = i - regime_lookback + 1
            if start < 0 or np.isnan(natr.iloc[i]):
                continue

            window = natr.iloc[start:i + 1].dropna()
            if len(window) < regime_lookback:
                continue

            low_threshold = np.percentile(window, low_percentile)
            high_threshold = np.percentile(window, high_percentile)
            current = natr.iloc[i]

            if current <= low_threshold:
                result[i] = 0
            elif current >= high_threshold:
                result[i] = 2
            else:
                result[i] = 1

        return (result,)


    def _run_price_level(self, df, source_df, cfg, meta):

        params = {p: s["default"] for p, s in meta["params"].items()}
        params.update(cfg.get("params", {}))

        lookback    = params["lookback_periods"]
        price_field = params["price_field"]

        result = np.full(len(df), np.nan)

        for i, ts in enumerate(df.index):

            completed = source_df[source_df.index < ts]

            if len(completed) >= lookback:
                result[i] = completed.iloc[-lookback][price_field]

        return (result,)


    # ─────────────────────────
    
    def _run_session_zone(self, df, cfg, meta):
        params      = {p: s["default"] for p, s in meta["params"].items()}
        params.update(cfg.get("params", {}))
    
        session     = params["session"]
        price_field = params["price_field"]
    
        sessions = {
            "london":  ("07:00", "16:00"),
            "newyork": ("13:00", "21:00"),
            "asian":   ("00:00", "09:00"),
        }
    
        start, end = sessions[session]
    
        work = df.copy()
        if not isinstance(work.index, pd.DatetimeIndex):
            work.index = pd.to_datetime(work["time"])
    
        work["date"] = work.index.date
    
        session_df     = work.between_time(start, end)
        agg_func       = "max" if price_field == "high" else "min"
        session_levels = session_df.groupby("date")[price_field].agg(agg_func)
    
        result = work["date"].map(session_levels).ffill().values.astype(float)
    
        return (result,)
    
    
    def _run_rolling_hl_zone(self, df, cfg, meta):
    
        params = {p: s["default"] for p, s in meta["params"].items()}
        params.update(cfg.get("params", {}))
    
        hours       = params["hours"]
        price_field = params["price_field"]
        window      = f"{hours}h"
    
        if price_field == "high":
            result = df["high"].rolling(window).max().values
        else:
            result = df["low"].rolling(window).min().values
    
        return (result,)
    
    def _run_trend(self, df, source_df, cfg, meta):
        key    = cfg["indicator"]
        params = {p: s["default"] for p, s in meta["params"].items()}
        params.update(cfg.get("params", {}))
    
        if key == "SLOPE_TREND":
            out = get_slope_trend(source_df, hours=params["hours"])
            return (out["slope"].values, out["slope_trend"].values)
    
        if key == "EMA_TREND":
            out = ema_trend(source_df)
            # Override spans if passed
            out["ema_fast"] = source_df["close"].ewm(span=params["fast_span"]).mean()
            out["ema_slow"] = source_df["close"].ewm(span=params["slow_span"]).mean()
            out["ema_trend"] = np.where(
                out["ema_fast"] > out["ema_slow"], "up",
                np.where(out["ema_fast"] < out["ema_slow"], "down", "flat")
            )
            return (out["ema_fast"].values, out["ema_slow"].values, out["ema_trend"].values)
    
        if key == "COMBINED_TREND":
            out = get_slope_trend(source_df, hours=params["hours"])
            out["ema_fast"] = source_df["close"].ewm(span=params["fast_span"]).mean()
            out["ema_slow"] = source_df["close"].ewm(span=params["slow_span"]).mean()
            out["ema_trend"] = np.where(
                out["ema_fast"] > out["ema_slow"], "up",
                np.where(out["ema_fast"] < out["ema_slow"], "down", "flat")
            )
            out = combine_trend(out)
            return (
                out["slope"].values,
                out["slope_trend"].values,
                out["ema_fast"].values,
                out["ema_slow"].values,
                out["ema_trend"].values,
                out["trend"].values,
            )
    
        raise ValueError(f"Unknown trend indicator: {key}")

    # ─────────────────────────

    def _run_fvg(self, df, source_df, cfg, meta):

        params = {p: s["default"] for p, s in meta["params"].items()}
        params.update(cfg.get("params", {}))

        lookback_bars  = params["lookback_bars"]
        lookback_hours = params["lookback_hours"]
        min_gap_pct    = params["min_gap_pct"]
        zone_index     = params["zone_index"]
        mitigated      = params["mitigated"]
        fvg_type       = meta["fvg_type"]          # "bullish" | "bearish"

        lo_arr = np.full(len(df), np.nan)
        hi_arr = np.full(len(df), np.nan)

        for i, ts in enumerate(df.index):

            completed = source_df[source_df.index < ts]

            hist = _slice_history(
                completed,
                lookback_bars=lookback_bars,
                lookback_hours=lookback_hours,
                ts=ts,
            )

            if len(hist) < 3:
                continue

            current_price = df["close"].iloc[i]

            gaps = self._detect_fvg(
                hist,
                fvg_type    = fvg_type,
                min_gap_pct = min_gap_pct,
                mitigated   = mitigated,
            )

            if not gaps:
                continue

            # Sort by proximity of gap midpoint to current price
            gaps.sort(key=lambda g: abs((g[0] + g[1]) / 2 - current_price))

            if zone_index < len(gaps):
                lo_arr[i] = gaps[zone_index][0]
                hi_arr[i] = gaps[zone_index][1]

        return (lo_arr, hi_arr)


    # ─────────────────────────
    # ZONE DETECTION
    # ─────────────────────────

    def _candle_body(self, o, c):
        return abs(c - o)

    def _candle_range(self, h, l):
        return h - l

    def _is_impulse(self, o, h, l, c, avg_body, multiplier=1.5):
        """
        Strong directional candle:
        - Body >= multiplier * avg_body
        - Body >= 60% of its own range (strong close, minimal wicks)
        """
        body = self._candle_body(o, c)
        rng  = self._candle_range(h, l)
        if rng == 0:
            return False
        return body >= multiplier * avg_body and (body / rng) >= 0.6

    def _is_base(self, o, h, l, c, avg_body):
        """
        Indecision / consolidation candle:
        - Body < 50% of average body  (doji, inside bar, spinning top)
        """
        body = self._candle_body(o, c)
        return body < avg_body * 0.5


    def _resample_ohlc(self, hist, timeframe_minutes):

        if timeframe_minutes in (None, 0):
            return hist

        return (
            hist[["open", "high", "low", "close"]]
            .resample(f"{timeframe_minutes}min")
            .agg({
                "open": "first",
                "high": "max",
                "low": "min",
                "close": "last",
            })
            .dropna()
        )


    def _detect_zones(self, hist, method, params):

        if method == "supply_demand":
            return self._detect_supply_demand_zones(hist, params)

        if method == "support_resistance":
            return self._detect_support_resistance_zones(hist, params)

        return []


    # ─────────────────────────
    # ZONE DETECTION
    # ─────────────────────────

    def _detect_supply_demand_zones(self, hist, params):
        zones = []
        max_base_candles = int(params.get("sd_max_base_candles", 6) or 6)
        min_base_candles = 2
        max_base_candles = max(max_base_candles, min_base_candles)
        block_range_multiplier = 2.4
        noisy_body_multiplier = 2.0
        base_close_ratio = 0.65
        displacement_multiplier = 1.5
        displacement_close_ratio = 0.6
        overlap_threshold = 0.5

        if len(hist) < 3:
            return zones

        o = hist["open"].values
        h = hist["high"].values
        l = hist["low"].values
        c = hist["close"].values

        ranges = np.maximum(h - l, 1e-10)
        bodies = np.abs(c - o)
        n = len(hist)

        for leg_out in range(2, n):
            ref_start = self._get_supply_demand_reference_start(hist, leg_out, params)
            ref_end = leg_out
            avg_body = np.median(bodies[ref_start:ref_end]) if ref_end > ref_start else bodies[leg_out]
            avg_range = np.median(ranges[ref_start:ref_end]) if ref_end > ref_start else ranges[leg_out]
            avg_body = avg_body if avg_body > 0 else 1e-10
            avg_range = avg_range if avg_range > 0 else 1e-10

            out_body = bodies[leg_out]
            out_range = ranges[leg_out]
            if out_body < avg_body * displacement_multiplier:
                continue
            if out_body / out_range < displacement_close_ratio:
                continue

            out_dir = 1 if c[leg_out] > o[leg_out] else -1 if c[leg_out] < o[leg_out] else 0
            if out_dir == 0:
                continue

            max_start = max(ref_start, leg_out - max_base_candles)
            best_for_leg = None

            for base_start in range(leg_out - min_base_candles, max_start - 1, -1):
                base_len = leg_out - base_start
                if base_len < min_base_candles:
                    continue

                base_bodies = bodies[base_start:leg_out]
                base_ranges = ranges[base_start:leg_out]
                base_low = float(np.min(l[base_start:leg_out]))
                base_high = float(np.max(h[base_start:leg_out]))
                base_span = max(base_high - base_low, 1e-10)

                if base_span > avg_range * block_range_multiplier:
                    continue
                if np.any(base_bodies > avg_body * noisy_body_multiplier):
                    continue
                if np.any(base_bodies / base_ranges > base_close_ratio):
                    continue

                if out_dir == 1:
                    if c[leg_out] <= base_high:
                        continue
                    location = (base_low - np.min(l[ref_start:leg_out])) / avg_range
                    if location > 1.5:
                        continue
                    departure = (c[leg_out] - base_high) / avg_range
                    score = float(
                        (out_body / avg_body) +
                        departure +
                        (base_len * 2.0) -
                        (base_span / avg_range)
                    )
                    candidate = ("demand", base_low, base_high, base_start, leg_out, score)
                else:
                    if c[leg_out] >= base_low:
                        continue
                    location = (np.max(h[ref_start:leg_out]) - base_high) / avg_range
                    if location > 1.5:
                        continue
                    departure = (base_low - c[leg_out]) / avg_range
                    score = float(
                        (out_body / avg_body) +
                        departure +
                        (base_len * 2.0) -
                        (base_span / avg_range)
                    )
                    candidate = ("supply", base_low, base_high, base_start, leg_out, score)

                if best_for_leg is None or candidate[5] > best_for_leg[5]:
                    best_for_leg = candidate

            if best_for_leg is not None:
                zones.append(best_for_leg)

        return self._suppress_overlapping_zones(zones, overlap_threshold)

    def _detect_support_resistance_zones(self, hist, params):
        zones = []
        timeframe_minutes = params.get("sr_timeframe_minutes") or 1
        context_bars = int((params.get("sr_hours", 0) * 60) / timeframe_minutes)
        context_bars = max(context_bars, 1)
        left_bars = 2
        right_bars = 2
        zone_buffer = params.get("zone_buffer", 0.0)
        min_cluster_touches = 2

        if len(hist) < left_bars + right_bars + 1:
            return zones

        h = hist["high"].values
        l = hist["low"].values
        c = hist["close"].values
        n = len(hist)
        ranges = np.maximum(h - l, 1e-10)
        typical_range = np.median(ranges) if len(ranges) else 1e-10
        typical_range = typical_range if typical_range > 0 else 1e-10
        cluster_buffer = max(typical_range * 0.8, np.median(c) * zone_buffer)
        max_touch_gap = max(right_bars + 1, min(30, max(4, context_bars // 6)))
        sweep_lookback = max(left_bars + 1, min(max_touch_gap, context_bars))
        sweep_depth = max(typical_range * 0.35, np.median(c) * zone_buffer)
        pivots = []

        for pivot in range(left_bars, n - right_bars):
            confirm_pos = pivot + right_bars

            left_highs = h[pivot - left_bars:pivot]
            right_highs = h[pivot + 1:pivot + right_bars + 1]
            if (
                    h[pivot] > np.max(left_highs) and
                    h[pivot] >= np.max(right_highs)):
                pivots.append(("resistance", pivot, confirm_pos, float(h[pivot])))

            left_lows = l[pivot - left_bars:pivot]
            right_lows = l[pivot + 1:pivot + right_bars + 1]
            if (
                    l[pivot] < np.min(left_lows) and
                    l[pivot] <= np.min(right_lows)):
                pivots.append(("support", pivot, confirm_pos, float(l[pivot])))

        for i in range(sweep_lookback, n - right_bars):
            prior_high = float(np.max(h[i - sweep_lookback:i]))
            if h[i] > prior_high + sweep_depth and c[i] < prior_high:
                buffer_amount = max(prior_high * zone_buffer, typical_range * 0.25)
                zones.append((
                    "resistance",
                    float(prior_high - buffer_amount),
                    float(h[i] + buffer_amount),
                    i,
                    i + right_bars,
                    float((h[i] - prior_high) / typical_range + 3.0),
                ))

            prior_low = float(np.min(l[i - sweep_lookback:i]))
            if l[i] < prior_low - sweep_depth and c[i] > prior_low:
                buffer_amount = max(prior_low * zone_buffer, typical_range * 0.25)
                zones.append((
                    "support",
                    float(l[i] - buffer_amount),
                    float(prior_low + buffer_amount),
                    i,
                    i + right_bars,
                    float((prior_low - l[i]) / typical_range + 3.0),
                ))

        for ztype in ("resistance", "support"):
            typed = [pivot for pivot in pivots if pivot[0] == ztype]
            typed.sort(key=lambda pivot: pivot[1])
            clusters = []

            for pivot in typed:
                _, pivot_pos, confirm_pos, level = pivot
                matched = None
                for cluster in clusters:
                    center = cluster["level_sum"] / cluster["count"]
                    if (
                            pivot_pos - cluster["last_pos"] <= max_touch_gap and
                            abs(level - center) <= cluster_buffer):
                        matched = cluster
                        break

                if matched is None:
                    clusters.append({
                        "positions": [pivot_pos],
                        "confirms": [confirm_pos],
                        "levels": [level],
                        "level_sum": level,
                        "count": 1,
                        "last_pos": pivot_pos,
                    })
                else:
                    matched["positions"].append(pivot_pos)
                    matched["confirms"].append(confirm_pos)
                    matched["levels"].append(level)
                    matched["level_sum"] += level
                    matched["count"] += 1
                    matched["last_pos"] = pivot_pos

            for cluster in clusters:
                if cluster["count"] < min_cluster_touches:
                    continue

                level_low = float(np.min(cluster["levels"]))
                level_high = float(np.max(cluster["levels"]))
                center = cluster["level_sum"] / cluster["count"]
                buffer_amount = max(center * zone_buffer, cluster_buffer * 0.5)
                zone_low = level_low - buffer_amount
                zone_high = level_high + buffer_amount
                start_pos = min(cluster["positions"])
                end_pos = max(cluster["confirms"])
                span = end_pos - start_pos + 1
                score = float((cluster["count"] * 3.0) + span - ((zone_high - zone_low) / typical_range))
                zones.append((ztype, float(zone_low), float(zone_high), start_pos, end_pos, score))

        return self._suppress_overlapping_zones(zones, 0.25)

    def _suppress_overlapping_zones(self, zones, overlap_threshold):
        kept = []
        for zone in sorted(zones, key=lambda item: item[5], reverse=True):
            ztype, lo, hi, start_pos, end_pos, _ = zone
            duplicate = False

            for kept_zone in kept:
                kept_type, kept_lo, kept_hi, kept_start, kept_end, _ = kept_zone
                if kept_type != ztype:
                    continue

                time_overlap = min(end_pos, kept_end) - max(start_pos, kept_start) + 1
                if time_overlap <= 0:
                    continue

                price_overlap = min(hi, kept_hi) - max(lo, kept_lo)
                if price_overlap <= 0:
                    continue

                time_ratio = time_overlap / max(1, min(end_pos - start_pos + 1, kept_end - kept_start + 1))
                price_ratio = price_overlap / max(1e-10, min(hi - lo, kept_hi - kept_lo))
                if time_ratio >= overlap_threshold and price_ratio >= overlap_threshold:
                    duplicate = True
                    break

            if not duplicate:
                kept.append(zone)

        return sorted(kept, key=lambda item: item[4])

    def _detect_fvg(self, hist, fvg_type, min_gap_pct, mitigated):

        gaps = []

        h = hist["high"].values
        l = hist["low"].values
        c = hist["close"].values
        o = hist["open"].values

        n = len(hist)
        bodies = np.abs(c - o)
        avg_body = np.mean(bodies) if np.mean(bodies) > 0 else 1e-10

        for i in range(1, n - 1):

            if fvg_type == "bullish":
                if c[i] <= o[i]:
                    continue

                if not self._is_impulse(o[i], h[i], l[i], c[i], avg_body):
                    continue

                gap_low = h[i - 1]
                gap_high = l[i + 1]

                if gap_high <= gap_low:
                    continue

                if c[i - 1] > 0 and min_gap_pct > 0:
                    if (gap_high - gap_low) / c[i - 1] < min_gap_pct:
                        continue

                # Mitigation: any candle AFTER the gap (i+2 onward) trades back into it
                if not mitigated:
                    future_lows = l[i + 2:]
                    if len(future_lows) > 0 and np.any(future_lows <= gap_high):
                        continue

                gaps.append((float(gap_low), float(gap_high)))

            elif fvg_type == "bearish":
                if c[i] >= o[i]:
                    continue

                if not self._is_impulse(o[i], h[i], l[i], c[i], avg_body):
                    continue

                gap_high = l[i - 1]
                gap_low = h[i + 1]

                if gap_low >= gap_high:
                    continue

                if c[i - 1] > 0 and min_gap_pct > 0:
                    if (gap_high - gap_low) / c[i - 1] < min_gap_pct:
                        continue

                # Mitigation: any candle AFTER the gap (i+2 onward) trades back into it
                if not mitigated:
                    future_highs = h[i + 2:]
                    if len(future_highs) > 0 and np.any(future_highs >= gap_low):
                        continue

                gaps.append((float(gap_low), float(gap_high)))

        return gaps


# ─────────────────────────────────────────────
# COLUMN WRITER
# ─────────────────────────────────────────────

class ColumnWriter:

    @staticmethod
    def write(df, outputs, values):

        for out, val in zip(outputs, values):

            #col = name if len(outputs) == 1 else f"{name}_{out}"
            col = out

            df[col] = val


# ─────────────────────────────────────────────
# PREPARE DATA
# ─────────────────────────────────────────────

def prepare_price_data(price_data):

    prepared = {}

    for tf, df in price_data.items():

        df = df.copy()

        if not isinstance(df.index, pd.DatetimeIndex):
            df.index = pd.to_datetime(df["time"])

        prepared[tf] = df

    return prepared


# ─────────────────────────────────────────────
# MAIN PIPELINE
# ─────────────────────────────────────────────

def set_indicators(config, price_data):

    price_data = prepare_price_data(price_data)

    validator = IndicatorValidator(price_data)

    executor  = IndicatorExecutor()

    prepared_config = []
    seen_outputs = {}

    for raw_cfg in config:

        cfg = raw_cfg.copy()

        tf        = cfg["timeframe"]

        validator.validate(cfg)

        meta, _ = _lookup(cfg["indicator"])
        resolved_outputs = _resolve_outputs(cfg, meta)

        for output in resolved_outputs:

            output_key = (tf, output)

            if output_key in seen_outputs:
                raise IndicatorValidationError(
                    f"Duplicate output '{output}' for timeframe '{tf}'"
                )

            seen_outputs[output_key] = cfg["indicator"]

        cfg["source_df"] = price_data[tf]
        cfg["resolved_outputs"] = resolved_outputs
        prepared_config.append(cfg)

    for cfg in prepared_config:

        df = price_data[cfg["timeframe"]]

        values = executor.run(df, cfg)

        if len(values) != len(cfg["resolved_outputs"]):
            raise IndicatorValidationError(
                f"{cfg['indicator']} returned {len(values)} values for "
                f"{len(cfg['resolved_outputs'])} outputs"
            )

        ColumnWriter.write(df, cfg["resolved_outputs"], values)

    return price_data


def get_slope_trend(df, hours=4):
    df = df.copy()

    def slope(series):
        y = series.values

        # remove NaNs
        mask = ~np.isnan(y)
        y = y[mask]

        # need at least 2 points
        if len(y) < 2:
            return np.nan

        x = np.arange(len(y))

        try:
            return np.polyfit(x, y, 1)[0]
        except:
            return np.nan

    df['slope'] = (
        df['close']
        .rolling(f'{hours}h')   # use lowercase 'h'
        .apply(slope, raw=False)
    )

    df['slope_trend'] = df['slope'].apply(
        lambda x: 'up' if x > 0 else ('down' if x < 0 else 'flat')
    )

    return df

def ema_trend(df, hours=4):
    df = df.copy()

    df['ema_fast'] = df['close'].ewm(span=9).mean()
    df['ema_slow'] = df['close'].ewm(span=50).mean()

    df['ema_trend'] = np.where(
        df['ema_fast'] > df['ema_slow'], 'up',
        np.where(df['ema_fast'] < df['ema_slow'], 'down', 'flat')
    )

    return df

def combine_trend(df):
    df = df.copy()
    
    df['trend'] = np.where(
        (df['ema_trend'] == 'up') & (df['slope_trend'] == 'up'), 'strong_up',
        np.where(
            (df['ema_trend'] == 'down') & (df['slope_trend'] == 'down'), 'strong_down',
            'weak'
        )
    )

    return df
