INDICATOR_REGISTRY = {
    "indicators": {},
    "candlestick_patterns": {},
    "price_levels": {},       # prev day/week highs & lows
    "zones": {},              # supply/demand & support/resistance zones
    "trends": {},              # trend
    "fvg": {}                 # fair value gaps
}

# ─────────────────────────────────────────────
# TREND INDICATORS
# ─────────────────────────────────────────────
INDICATOR_REGISTRY["indicators"]["SMA"] = {
    "name": "Simple Moving Average",
    "category": "trend",
    "library": "talib",
    "function": "SMA",
    "inputs": {"required": ["close"]},
    "params": {
        "timeperiod": {"type": "int", "default": 14, "min": 1, "max": 500}
    },
    "outputs": ["sma"],
    "ui": {"group": "Moving Averages", "overlay": True}
}
INDICATOR_REGISTRY["indicators"]["EMA"] = {
    "name": "Exponential Moving Average",
    "category": "trend",
    "library": "talib",
    "function": "EMA",
    "inputs": {"required": ["close"]},
    "params": {
        "timeperiod": {"type": "int", "default": 14, "min": 1, "max": 500}
    },
    "outputs": ["ema"],
    "ui": {"group": "Moving Averages", "overlay": True}
}
INDICATOR_REGISTRY["indicators"]["WMA"] = {
    "name": "Weighted Moving Average",
    "category": "trend",
    "library": "talib",
    "function": "WMA",
    "inputs": {"required": ["close"]},
    "params": {
        "timeperiod": {"type": "int", "default": 14}
    },
    "outputs": ["wma"],
    "ui": {"group": "Moving Averages", "overlay": True}
}
for ind in ["DEMA", "TEMA", "KAMA"]:
    INDICATOR_REGISTRY["indicators"][ind] = {
        "name": ind,
        "category": "trend",
        "library": "talib",
        "function": ind,
        "inputs": {"required": ["close"]},
        "params": {
            "timeperiod": {"type": "int", "default": 14}
        },
        "outputs": [ind.lower()],
        "ui": {"group": "Moving Averages", "overlay": True}
    }
INDICATOR_REGISTRY["indicators"]["SAR"] = {
    "name": "Parabolic SAR",
    "category": "trend",
    "library": "talib",
    "function": "SAR",
    "inputs": {"required": ["high", "low"]},
    "params": {
        "acceleration": {"type": "float", "default": 0.02},
        "maximum":      {"type": "float", "default": 0.2}
    },
    "outputs": ["sar"],
    "ui": {"group": "Trend", "overlay": True}
}
INDICATOR_REGISTRY["indicators"]["ADX"] = {
    "name": "Average Directional Index",
    "category": "trend",
    "library": "talib",
    "function": "ADX",
    "inputs": {"required": ["high", "low", "close"]},
    "params": {"timeperiod": {"type": "int", "default": 14}},
    "outputs": ["adx"],
    "ui": {"group": "Trend Strength", "overlay": False}
}
for ind in ["PLUS_DI", "MINUS_DI"]:
    INDICATOR_REGISTRY["indicators"][ind] = {
        "name": ind,
        "category": "trend",
        "library": "talib",
        "function": ind,
        "inputs": {"required": ["high", "low", "close"]},
        "params": {"timeperiod": {"type": "int", "default": 14}},
        "outputs": [ind.lower()],
        "ui": {"group": "Trend Strength", "overlay": False}
    }

# ─────────────────────────────────────────────
# MOMENTUM INDICATORS
# ─────────────────────────────────────────────
INDICATOR_REGISTRY["indicators"]["RSI"] = {
    "name": "Relative Strength Index",
    "category": "momentum",
    "library": "talib",
    "function": "RSI",
    "inputs": {"required": ["close"]},
    "params": {"timeperiod": {"type": "int", "default": 14}},
    "outputs": ["rsi"],
    "ui": {"group": "Momentum", "overlay": False}
}
INDICATOR_REGISTRY["indicators"]["MACD"] = {
    "name": "MACD",
    "category": "momentum",
    "library": "talib",
    "function": "MACD",
    "inputs": {"required": ["close"]},
    "params": {
        "fastperiod":   {"type": "int", "default": 12},
        "slowperiod":   {"type": "int", "default": 26},
        "signalperiod": {"type": "int", "default": 9}
    },
    "outputs": ["macd", "signal", "hist"],
    "ui": {"group": "Momentum", "overlay": False}
}
for ind in ["STOCH", "STOCHF"]:
    INDICATOR_REGISTRY["indicators"][ind] = {
        "name": ind,
        "category": "momentum",
        "library": "talib",
        "function": ind,
        "inputs": {"required": ["high", "low", "close"]},
        "params": {},
        "outputs": ["slowk", "slowd"] if ind == "STOCH" else ["fastk", "fastd"],
        "ui": {"group": "Momentum", "overlay": False}
    }
for ind in ["CCI", "ROC", "MOM", "TRIX"]:
    INDICATOR_REGISTRY["indicators"][ind] = {
        "name": ind,
        "category": "momentum",
        "library": "talib",
        "function": ind,
        "inputs": {"required": ["close"]},
        "params": {"timeperiod": {"type": "int", "default": 14}},
        "outputs": [ind.lower()],
        "ui": {"group": "Momentum", "overlay": False}
    }

# ─────────────────────────────────────────────
# VOLATILITY INDICATORS
# ─────────────────────────────────────────────
for ind in ["ATR", "NATR"]:
    INDICATOR_REGISTRY["indicators"][ind] = {
        "name": ind,
        "category": "volatility",
        "library": "talib",
        "function": ind,
        "inputs": {"required": ["high", "low", "close"]},
        "params": {"timeperiod": {"type": "int", "default": 14}},
        "outputs": [ind.lower()],
        "ui": {"group": "Volatility", "overlay": False}
    }
INDICATOR_REGISTRY["indicators"]["BBANDS"] = {
    "name": "Bollinger Bands",
    "category": "volatility",
    "library": "talib",
    "function": "BBANDS",
    "inputs": {"required": ["close"]},
    "params": {
        "timeperiod": {"type": "int", "default": 20},
        "nbdevup":    {"type": "float", "default": 2},
        "nbdevdn":    {"type": "float", "default": 2}
    },
    "outputs": ["bbands_upper", "bbands_middle", "bbands_lower"],
    "ui": {"group": "Volatility", "overlay": True}
}
INDICATOR_REGISTRY["indicators"]["VOLATILITY_REGIME"] = {
    "name": "Volatility Regime",
    "category": "volatility",
    "library": "custom",
    "function": "VOLATILITY_REGIME",
    "inputs": {"required": ["high", "low", "close"]},
    "params": {
        "timeperiod": {"type": "int", "default": 14, "min": 1, "max": 500},
        "regime_lookback": {"type": "int", "default": 100, "min": 2, "max": 5000},
        "low_percentile": {"type": "float", "default": 33, "min": 0, "max": 100},
        "high_percentile": {"type": "float", "default": 66, "min": 0, "max": 100}
    },
    "outputs": ["volatility_regime"],
    "output_type": "scalar",
    "ui": {"group": "Volatility", "overlay": False}
}

# ─────────────────────────────────────────────
# VOLUME INDICATORS
# ─────────────────────────────────────────────
for ind in ["OBV", "MFI", "AD", "ADOSC"]:
    INDICATOR_REGISTRY["indicators"][ind] = {
        "name": ind,
        "category": "volume",
        "library": "talib",
        "function": ind,
        "inputs": {"required": ["high", "low", "close", "volume"]},
        "params": {},
        "outputs": [ind.lower()],
        "ui": {"group": "Volume", "overlay": False}
    }

# ─────────────────────────────────────────────
# PRICE TRANSFORMS
# ─────────────────────────────────────────────
for ind in ["LINEARREG", "LINEARREG_SLOPE"]:
    INDICATOR_REGISTRY["indicators"][ind] = {
        "name": ind,
        "category": "price_transform",
        "library": "talib",
        "function": ind,
        "inputs": {"required": ["close"]},
        "params": {"timeperiod": {"type": "int", "default": 14}},
        "outputs": [ind.lower()],
        "ui": {"group": "Price Transform", "overlay": False}
    }

# ─────────────────────────────────────────────
# CANDLESTICK PATTERNS
# ─────────────────────────────────────────────
def _cdl(name, desc):
    return {
        "name": desc,
        "category": "candlestick",
        "library": "talib",
        "function": name,
        "inputs": {"required": ["open", "high", "low", "close"]},
        "params": {},
        "outputs": [name.lower()],
        "signal_meaning": {100: "Bullish", -100: "Bearish", 0: "None"},
        "ui": {"group": "Candlestick Patterns"}
    }

for cdl, desc in {
    "CDLENGULFING":       "Engulfing",
    "CDLHAMMER":          "Hammer",
    "CDLINVERTEDHAMMER":  "Inverted Hammer",
    "CDLSHOOTINGSTAR":    "Shooting Star",
    "CDLDOJI":            "Doji",
    "CDLDRAGONFLYDOJI":   "Dragonfly Doji",
    "CDLGRAVESTONEDOJI":  "Gravestone Doji",
    "CDLMORNINGSTAR":     "Morning Star",
    "CDLEVENINGSTAR":     "Evening Star",
    "CDLPIERCING":        "Piercing",
    "CDLDARKCLOUDCOVER":  "Dark Cloud Cover",
    "CDL3WHITESOLDIERS":  "Three White Soldiers",
    "CDL3BLACKCROWS":     "Three Black Crows",
    "CDLHARAMI":          "Harami",
    "CDLHARAMICROSS":     "Harami Cross",
    "CDLSPINNINGTOP":     "Spinning Top",
    "CDLTAKURI":          "Takuri",
    "CDLUPSIDEGAP2CROWS": "Upside Gap Two Crows",
    "CDLSEPARATINGLINES": "Separating Lines"
}.items():
    INDICATOR_REGISTRY["candlestick_patterns"][cdl] = _cdl(cdl, desc)


# ─────────────────────────────────────────────
# PRICE LEVELS
# ─────────────────────────────────────────────

def _price_level(desc, lookback, price_field, outputs=None):
    if outputs is None:
        outputs = []
    return {
        "name": desc,
        "category": "price_level",
        "library": "custom",
        "inputs": {"required": ["high", "low"]},
        "params": {
            "lookback_periods": {
                "type": "int",
                "default": lookback,
                "min": 1,
                "max": 30
            },
            "price_field": {
                "type": "str",
                "default": price_field,
                "choices": ["high", "low"]
            }
        },
        "outputs": outputs,
        "output_type": "scalar",
        "ui": {"group": "Price Levels", "overlay": True}
    }

INDICATOR_REGISTRY["price_levels"]["PREV_DAY_HIGH"] = _price_level(
    "Previous Day High", 1, "high", ["prev_day_high"]
)
INDICATOR_REGISTRY["price_levels"]["PREV_DAY_LOW"] = _price_level(
    "Previous Day Low", 1, "low", ["prev_day_low"]
)
INDICATOR_REGISTRY["price_levels"]["DAY_BEFORE_PREV_HIGH"] = _price_level(
    "Day Before Previous Day High", 2, "high", ["day_before_prev_day_high"]
)
INDICATOR_REGISTRY["price_levels"]["DAY_BEFORE_PREV_LOW"] = _price_level(
    "Day Before Previous Day Low", 2, "low", ["day_before_prev_day_low"]
)
INDICATOR_REGISTRY["price_levels"]["LAST_WEEK_HIGH"] = _price_level(
    "Last Week High", 1, "high", ["last_week_high"]
)
INDICATOR_REGISTRY["price_levels"]["LAST_WEEK_LOW"] = _price_level(
    "Last Week Low", 1, "low", ["last_week_low"]
)


# ─────────────────────────────────────────────
# ZONES
# ─────────────────────────────────────────────

def _zone(desc, detection_method, extra_params=None, zone=None):
    base_params = {
        "lookback_bars": {
            "type": "int",
            "default": 50,
            "min": 0,
            "max": 500
        },
        "lookback_hours": {
            "type": "int",
            "default": 0,
            "min": 0,
            "max": 720
        },
        "zone_index": {
            "type": "int",
            "default": 0,
            "min": 0,
            "max": 10
        },
    }
    if extra_params:
        base_params.update(extra_params)
    return {
        "name": desc,
        "category": "zone",
        "library": "custom",
        "detection_method": detection_method,
        "inputs": {"required": ["open", "high", "low", "close"]},
        "params": base_params,
        "outputs": [f"{zone}_low", f"{zone}_high"],
        "output_type": "zone",
        "ui": {"group": "Zones", "overlay": True}
    }


# ── Supply / Demand ───────────────────────────────────────────────────────────
INDICATOR_REGISTRY["zones"]["SUPPLY_ZONE"] = _zone(
    "Supply Zone", "supply_demand",
    extra_params={
        "sd_lookback": {"type": "int", "default": 60, "min": 1, "max": 1440},
        "sd_lookback_hours": {"type": "float", "default": 0, "min": 0, "max": 720},
        "sd_max_base_candles": {"type": "int", "default": 30, "min": 2, "max": 300}
    },
    zone="supply"
)
INDICATOR_REGISTRY["zones"]["DEMAND_ZONE"] = _zone(
    "Demand Zone", "supply_demand",
    extra_params={
        "sd_lookback": {"type": "int", "default": 60, "min": 1, "max": 1440},
        "sd_lookback_hours": {"type": "float", "default": 0, "min": 0, "max": 720},
        "sd_max_base_candles": {"type": "int", "default": 30, "min": 2, "max": 300}
    },
    zone="demand"
)

# ── Support / Resistance ──────────────────────────────────────────────────────
INDICATOR_REGISTRY["zones"]["RESISTANCE_ZONE"] = _zone(
    "Resistance Zone", "support_resistance",
    extra_params={
        "sr_hours":              {"type": "int",   "default": 24,     "min": 1,   "max": 720},
        "sr_timeframe_minutes":  {"type": "int",   "default": 15,     "min": 1,   "max": 1440},
        "zone_buffer":           {"type": "float", "default": 0.0003, "min": 0.0, "max": 0.01},
    },
    zone="resistance"
)
INDICATOR_REGISTRY["zones"]["SUPPORT_ZONE"] = _zone(
    "Support Zone", "support_resistance",
    extra_params={
        "sr_hours":              {"type": "int",   "default": 24,     "min": 1,   "max": 720},
        "sr_timeframe_minutes":  {"type": "int",   "default": 15,     "min": 1,   "max": 1440},
        "zone_buffer":           {"type": "float", "default": 0.0003, "min": 0.0, "max": 0.01},
    },
    zone="support"
)

# ── Session High / Low ────────────────────────────────────────────────────────
def _session_zone(desc, session, price_field, outputs=None):
    if outputs is None:
        outputs = []
    return {
        "name": desc,
        "category": "zone",
        "library": "custom",
        "detection_method": "session",
        "inputs": {"required": ["high", "low"]},
        "params": {
            "session": {
                "type": "str",
                "default": session,
                "choices": ["london", "newyork", "asian"]
            },
            "price_field": {
                "type": "str",
                "default": price_field,
                "choices": ["high", "low"]
            }
        },
        "outputs": outputs,
        "output_type": "scalar",
        "ui": {"group": "Zones", "overlay": True}
    }

INDICATOR_REGISTRY["zones"]["LONDON_HIGH"]   = _session_zone("London High",   "london",  "high", outputs=["london_high"])
INDICATOR_REGISTRY["zones"]["LONDON_LOW"]    = _session_zone("London Low",    "london",  "low", outputs=["london_low"])
INDICATOR_REGISTRY["zones"]["NEWYORK_HIGH"]  = _session_zone("New York High", "newyork", "high", outputs=["newyork_high"])
INDICATOR_REGISTRY["zones"]["NEWYORK_LOW"]   = _session_zone("New York Low",  "newyork", "low", outputs=["newyork_low"])
INDICATOR_REGISTRY["zones"]["ASIAN_HIGH"]    = _session_zone("Asian High",    "asian",   "high", outputs=["asian_high"])
INDICATOR_REGISTRY["zones"]["ASIAN_LOW"]     = _session_zone("Asian Low",     "asian",   "low", outputs=["asian_low"])

# ── Rolling High / Low by Hours ───────────────────────────────────────────────
def _rolling_hl_zone(desc, price_field, outputs=None):
    if outputs is None:
        outputs = []
    return {
        "name": desc,
        "category": "zone",
        "library": "custom",
        "detection_method": "rolling_hl",
        "inputs": {"required": ["high", "low"]},
        "params": {
            "hours": {
                "type": "int",
                "default": 4,
                "min": 1,
                "max": 168
            },
            "price_field": {
                "type": "str",
                "default": price_field,
                "choices": ["high", "low"]
            }
        },
        "outputs": outputs,
        "output_type": "scalar",
        "ui": {"group": "Zones", "overlay": True}
    }

INDICATOR_REGISTRY["zones"]["ROLLING_HIGH"] = _rolling_hl_zone("Rolling High by Hours", "high", outputs=["rolling_high"])
INDICATOR_REGISTRY["zones"]["ROLLING_LOW"]  = _rolling_hl_zone("Rolling Low by Hours",  "low", outputs=["rolling_low"])

# ─────────────────────────────────────────────
# TRENDS
# ─────────────────────────────────────────────

def _trend(desc, outputs, output_type="scalar"):
    return {
        "name": desc,
        "category": "trend",
        "library": "custom",
        "inputs": {"required": ["close"]},
        "params": {
            "hours": {
                "type": "int",
                "default": 4,
                "min": 1,
                "max": 72
            }
        },
        "outputs": outputs,
        "output_type": output_type,
        "ui": {"group": "Trends", "overlay": False}
    }

INDICATOR_REGISTRY["trends"]["SLOPE_TREND"] = _trend(
    "Slope Trend",
    outputs=["slope", "slope_trend"],
    output_type="multi"
)
INDICATOR_REGISTRY["trends"]["EMA_TREND"] = {
    **_trend("EMA Trend", outputs=["ema_fast", "ema_slow", "ema_trend"], output_type="multi"),
    "inputs": {"required": ["close"]},
    "params": {
        "fast_span": {
            "type": "int",
            "default": 9,
            "min": 2,
            "max": 50
        },
        "slow_span": {
            "type": "int",
            "default": 50,
            "min": 5,
            "max": 200
        }
    }
}
INDICATOR_REGISTRY["trends"]["COMBINED_TREND"] = {
    "name": "Combined Trend",
    "category": "trend",
    "library": "custom",
    "inputs": {"required": ["close"]},
    "params": {
        "hours": {
            "type": "int",
            "default": 4,
            "min": 1,
            "max": 72
        },
        "fast_span": {
            "type": "int",
            "default": 9,
            "min": 2,
            "max": 50
        },
        "slow_span": {
            "type": "int",
            "default": 50,
            "min": 5,
            "max": 200
        }
    },
    "outputs": ["slope", "slope_trend", "ema_fast", "ema_slow", "ema_trend", "trend"],
    "output_type": "multi",
    "ui": {"group": "Trends", "overlay": False}
}


# ─────────────────────────────────────────────
# FAIR VALUE GAPS (FVG)
# ─────────────────────────────────────────────
# Pattern: 3-candle sequence where candle[1]'s move leaves a gap
# between candle[0]'s high and candle[2]'s low  (bullish FVG)
# or between candle[0]'s low and candle[2]'s high (bearish FVG).
#
# Outputs: low and high of the gap itself.
# fvg_type param filters which direction to return.

def _fvg(desc, fvg_type, outputs=None):
    if outputs is None:
        outputs = []
    return {
        "name": desc,
        "category": "fvg",
        "library": "custom",
        "fvg_type": fvg_type,           # "bullish" | "bearish"
        "inputs": {"required": ["high", "low", "close"]},
        "params": {
            "lookback_bars":  {"type": "int",   "default": 100},
            "lookback_hours": {"type": "float", "default": None},
            "min_gap_pct":    {
                "type":    "float",
                "default": 0.0,         # 0 = any gap; set e.g. 0.0005 to filter tiny gaps
                "min":     0.0,
                "max":     0.1
            },
            "zone_index":     {"type": "int",   "default": 0},
            "mitigated":      {
                "type":    "bool",
                "default": False        # False = skip gaps price has already returned into
            }
        },
        "outputs": outputs,
        "output_type": "zone",
        "ui": {"group": "Fair Value Gaps", "overlay": True}
    }

INDICATOR_REGISTRY["fvg"]["BULLISH_FVG"] = _fvg("Bullish Fair Value Gap", "bullish", ["bullish_fvg_low", "bullish_fvg_high"])
INDICATOR_REGISTRY["fvg"]["BEARISH_FVG"] = _fvg("Bearish Fair Value Gap", "bearish", ["bearish_fvg_low", "bearish_fvg_high"])
