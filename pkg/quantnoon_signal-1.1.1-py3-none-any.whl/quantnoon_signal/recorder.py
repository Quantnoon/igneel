import os

import requests
from dotenv import load_dotenv

load_dotenv()

REQUEST_TIMEOUT_SECONDS = 10


class SignalRecorder:
    def __init__(self):
        self.webhook_url = os.getenv("RECORD_WEBHOOK_URL")
        self.webhook_secret = os.getenv("WEBHOOK_SECRET")

        if not self.webhook_url:
            raise ValueError("Missing RECORD_WEBHOOK_URL")
        if not self.webhook_secret:
            raise ValueError("Missing WEBHOOK_SECRET")

    def send_record_webhook(self, algo_name, trade_date, sl, op, tp, position, exit_date, gain):
        """Send a completed trade record to the recorder webhook.

        Args:
            algo_name: Name of the trading algorithm that produced the trade.
            trade_date: Trade entry date as provided by the caller.
            sl: Stop-loss price for the trade.
            op: Open or entry price for the trade.
            tp: Take-profit price for the trade.
            position: Trade direction or position label, for example "buy" or "sell".
            exit_date: Trade exit date as provided by the caller.
            gain: Final profit or loss value for the trade.

        Returns:
            The parsed JSON response from the webhook when available. If the webhook
            response is not JSON, returns a dictionary with `status` and `text`.
        """
        payload = {
            "algoIdentifier": algo_name,
            "trade_date": trade_date,
            "sl": sl,
            "op": op,
            "tp": tp,
            "position": position,
            "exit_date": exit_date,
            "gain": gain,
        }

        headers = {
            "Content-Type": "application/json",
            "x-webhook-secret": self.webhook_secret,
        }

        response = {}

        try:
            response = requests.post(
                self.webhook_url,
                json=payload,
                headers=headers,
                timeout=REQUEST_TIMEOUT_SECONDS,
            )
            return response.json()
        except ValueError:
            return {
                "status": response.status_code,
                "text": response.text,
            }
        except requests.RequestException as exc:
            return {
                "status": "error",
                "text": str(exc),
            }
